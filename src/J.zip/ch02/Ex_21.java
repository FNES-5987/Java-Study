package ch02;

public class Ex_21 {
    public static void main(String[] args) {
        // 문제 1번
        int x = 5;
        System.out.println(x);
        System.out.println(++x);

        System.out.println("---------");

        // 문제 2번
        int y = 7;
        System.out.println(y--);
        System.out.println(--y);

        System.out.println("---------");

        // 문제 3번
        int a = 10;
        System.out.println(a);
        a--; a--; a--;
        System.out.println(a);

        System.out.println("---------");

        // 문제 4번
        int b = 10;
        ++b; ++b; ++b;
        System.out.println(++b);

        System.out.println("---------");

        // 문제 5번
        int i = 3;
        System.out.println(i);
        i++; i++;
        System.out.println(i);

        System.out.println("---------");

        // 문제 6번
        int j = 6;
        System.out.println(j);
        System.out.println(--j);

        System.out.println("---------");

        // 문제 7번
        int n = 8;
        System.out.println(n);
        n--; n--; n--;
        System.out.println(n);

        System.out.println("---------");

        // 문제 8번
        int m = 12;
        System.out.println(m);
        ++m; ++m; ++m; ++m;
        System.out.println(++m);

        System.out.println("---------");

        //문제 9번
        int p = 2;
        System.out.println(p);
        p++; p++; p++; p++;
        System.out.println(p);

        System.out.println("---------");

        // 문제 10번
        int q = 9;
        System.out.println(q);
        --q; --q;
        System.out.println(q);
    }
}
