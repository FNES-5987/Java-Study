package ch02;

public class AritgmeticEx {
    public static void main(String[] args) {

    }
}
