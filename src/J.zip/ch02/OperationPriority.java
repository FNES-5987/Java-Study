package ch02;

public class OperationPriority {
    public static void main(String[] args) {
        // 대입연산
        // += -= *= /= %=
        int num = 10;
        num += 10; // num = num + 10
        num -= 10; // num = num - 10
    }
}
