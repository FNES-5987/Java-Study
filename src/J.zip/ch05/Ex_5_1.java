package ch05;

public class Ex_5_1 {
    public static void main(String[] args) {
        Student student = new Student();
        student.setName("Jone");
        student.setGrade(10);
        student.printStudentInfo();

        Student student1 = new Student();
        student1.setName("Lisa");
        student1.setGrade(11);
        student1.upGrade();
        student1.setAge(16);
        student1.printStudentInfo();
    }

}
