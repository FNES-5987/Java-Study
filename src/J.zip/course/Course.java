package course;

public class Course {
    private String Course; // 과목
    private String student; // 학생
}
