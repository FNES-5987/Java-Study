package course;

public class Main {
    public static void main(String[] args) {
        CourseService courseService = new CourseService(3,10);
    }
    }
