public class Main {
    public static void main(String[] args) {
        System.out.println("Hello Java");
        System.out.println("Hello IntelliJ"); //sout 단축키다.
    }
}