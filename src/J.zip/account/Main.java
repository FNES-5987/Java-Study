package account;

public class Main {
    public static void main(String[] args) {
        AccountManagement accountManagement = new AccountManagement(100);
        accountManagement.run();

    }
}
