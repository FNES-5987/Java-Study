package ch01;

public class Ex_2 {
    public static void main(String[] args){
        int a = 5;
        double b = a;
        System.out.println(b);

        double c = 3.14;
        int d = (int) c;
        System.out.println(d);

        int e = 10;
        String f = Integer.toString(e);
        System.out.println(f);

        char g = 'A';
        int h = (char) g;
        System.out.println(h);

        double i = 2.5;
        int j = (int) i;
        System.out.println(j);
    }
}
