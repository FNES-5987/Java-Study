package ch01;

public class StringEx_ {
    public static void main(String[] args){
        String hi = "Hello\tGuys!\n";
        String name = "\nMy name is \"Jo\"";
        String phone = "and My phone number is\n010-0000-0000";
        String bye = "\nThank you very MMMMMMMMMMMMMMMACH!!!!!!!!!!!";
        String hello = hi + name + phone + bye;
        System.out.println(hello);
    }
}
